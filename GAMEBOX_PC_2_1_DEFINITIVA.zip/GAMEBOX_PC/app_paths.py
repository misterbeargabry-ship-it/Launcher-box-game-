"""Percorsi robusti per risorse incluse e dati persistenti di GAMEBOX PC."""
import os
import sys


def resource_path(*parts):
    """Restituisce il percorso di una risorsa inclusa nel pacchetto."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, *parts)


def app_storage_dir():
    """Cartella persistente dell'applicazione, scrivibile anche da Program Files."""
    if sys.platform == "win32":
        root = os.environ.get("LOCALAPPDATA") or os.path.expanduser("~")
    elif sys.platform == "darwin":
        root = os.path.join(os.path.expanduser("~"), "Library", "Application Support")
    else:
        root = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    path = os.path.join(root, "GAMEBOX_PC")
    os.makedirs(path, exist_ok=True)
    return path


def writable_data_dir():
    path = os.path.join(app_storage_dir(), "data")
    os.makedirs(path, exist_ok=True)
    return path


def writable_dir(name):
    """Cartella persistente dedicata (Games, APK, Downloads, Covers, Shortcuts)."""
    path = os.path.join(app_storage_dir(), name)
    os.makedirs(path, exist_ok=True)
    return path
