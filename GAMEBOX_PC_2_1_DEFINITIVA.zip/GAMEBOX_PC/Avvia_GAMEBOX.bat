@echo off
setlocal
cd /d "%~dp0"
title GAMEBOX PC

where python >nul 2>nul
if errorlevel 1 (
  echo [ERRORE] Python 3 non trovato. Installa Python 3.10+ e abilita "Add Python to PATH".
  pause
  exit /b 1
)

if not exist "venv\Scripts\python.exe" (
  echo [GAMEBOX] Preparazione ambiente al primo avvio...
  python -m venv venv
  if errorlevel 1 goto error
)

call "venv\Scripts\activate.bat"
python -m pip install --upgrade pip
if errorlevel 1 goto error
python -m pip install -r requirements.txt
if errorlevel 1 goto error

echo [GAMEBOX] Avvio...
python main.py
if errorlevel 1 goto error
exit /b 0

:error
echo.
echo [ERRORE] Operazione non riuscita. Verifica la connessione e i messaggi sopra.
pause
exit /b 1
