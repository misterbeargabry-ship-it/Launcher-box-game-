"""
home_page.py
--------------
Schermata Home in stile console: sfondo con gradiente dinamico animato,
fila orizzontale di grandi copertine (GameTile), pannello inferiore con
dettagli del gioco selezionato e avvio rapido.

NOTA SUL FRAME RATE: il ciclo di animazione dello sfondo e del bagliore
gira a un intervallo di ~8 ms (~120 Hz) per restare il piu' fluido
possibile; la fluidita' realmente visibile sullo schermo dipende pero'
dalla frequenza di aggiornamento del monitor dell'utente (su un monitor
a 60 Hz l'immagine sara' comunque vincolata a 60 Hz).
"""

import math

from PySide6.QtCore import Qt, QTimer, QPointF
from PySide6.QtGui import QPainter, QLinearGradient, QColor, QRadialGradient
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QScrollArea,
    QSizePolicy, QMessageBox
)

from game_manager import GameManagerError
from apk_manager import ApkManagerError
from ui.widgets.game_tile import GameTile, TILE_W, TILE_H

ANIMATION_INTERVAL_MS = 8  # ~120 Hz di refresh interno per lo sfondo dinamico


class HomeBackground(QWidget):
    """Pannello di sfondo con gradiente animato in stile 'console dashboard'."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._phase = 0.0
        self.setAttribute(Qt.WA_StyledBackground, True)
        self.accent_color = QColor(138, 43, 226)  # viola di default

    def advance(self, dt_ms: int):
        self._phase += dt_ms / 1000.0
        self.update()

    def set_accent(self, qcolor: QColor):
        self.accent_color = qcolor
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        base = QLinearGradient(0, 0, self.width(), self.height())
        base.setColorAt(0.0, QColor(10, 10, 18))
        base.setColorAt(1.0, QColor(16, 12, 26))
        painter.fillRect(self.rect(), base)

        # Macchia di luce che si sposta lentamente, colorata in base al
        # gioco selezionato (accent_color), per dare un senso di
        # "dashboard viva" come le home screen delle console moderne.
        cx = self.width() * (0.5 + 0.08 * math.sin(self._phase * 0.6))
        cy = self.height() * (0.35 + 0.05 * math.cos(self._phase * 0.4))
        radius = max(self.width(), self.height()) * 0.55

        glow = QRadialGradient(QPointF(cx, cy), radius)
        c = QColor(self.accent_color)
        c.setAlpha(70)
        glow.setColorAt(0.0, c)
        transparent = QColor(self.accent_color)
        transparent.setAlpha(0)
        glow.setColorAt(1.0, transparent)
        painter.fillRect(self.rect(), glow)


class HomePage(QWidget):
    def __init__(self, game_manager, apk_manager, on_change=None, parent=None):
        super().__init__(parent)
        self.game_manager = game_manager
        self.apk_manager = apk_manager
        self.on_change = on_change
        self.tiles = []
        self.selected_game_id = None

        self._build_ui()
        self.refresh()

        # Ciclo di animazione continuo (sfondo dinamico), ~120 Hz
        self._timer = QTimer(self)
        self._timer.setInterval(ANIMATION_INTERVAL_MS)
        self._timer.timeout.connect(self._on_tick)
        self._timer.start()

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        self.background = HomeBackground(self)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)

        # Il contenuto vero e proprio sta sopra lo sfondo animato
        content = QWidget()
        content.setAttribute(Qt.WA_TranslucentBackground, False)
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(32, 24, 32, 24)
        content_layout.setSpacing(16)

        title = QLabel("GAMEBOX PC")
        title.setObjectName("PageTitle")
        subtitle = QLabel("La tua libreria, in stile console")
        subtitle.setObjectName("PageSubtitle")
        content_layout.addWidget(title)
        content_layout.addWidget(subtitle)

        # Striscia statistiche rapide
        self.stats_label = QLabel()
        self.stats_label.setObjectName("GameCardMeta")
        content_layout.addWidget(self.stats_label)

        # Carosello orizzontale
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameShape(QScrollArea.NoFrame)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.scroll_area.setFixedHeight(TILE_H + 24)

        self.row_container = QWidget()
        self.row_layout = QHBoxLayout(self.row_container)
        self.row_layout.setSpacing(18)
        self.row_layout.setAlignment(Qt.AlignLeft)
        self.scroll_area.setWidget(self.row_container)
        content_layout.addWidget(self.scroll_area)

        # Pannello dettagli / avvio rapido del gioco selezionato
        self.detail_panel = QWidget()
        detail_layout = QHBoxLayout(self.detail_panel)
        detail_layout.setContentsMargins(0, 12, 0, 0)

        info_col = QVBoxLayout()
        self.detail_title = QLabel("Nessun gioco selezionato")
        self.detail_title.setObjectName("GameCardTitle")
        self.detail_title.setStyleSheet("font-size: 20px;")
        self.detail_meta = QLabel("")
        self.detail_meta.setObjectName("GameCardMeta")
        info_col.addWidget(self.detail_title)
        info_col.addWidget(self.detail_meta)
        detail_layout.addLayout(info_col, 1)

        self.play_button = QPushButton("▶  Avvia")
        self.play_button.setObjectName("PrimaryButton")
        self.play_button.setMinimumHeight(44)
        self.play_button.setMinimumWidth(160)
        self.play_button.clicked.connect(self._launch_selected)
        detail_layout.addWidget(self.play_button)

        content_layout.addWidget(self.detail_panel)
        content_layout.addStretch()

        root.addWidget(content)

    def resizeEvent(self, event):
        self.background.setGeometry(0, 0, self.width(), self.height())
        self.background.lower()
        super().resizeEvent(event)

    # ------------------------------------------------------------------ #
    def refresh(self):
        games = self.game_manager.list_games()

        while self.row_layout.count():
            item = self.row_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self.tiles = []

        if not games:
            empty = QLabel(
                "La libreria e' vuota. Vai su \"Libreria Giochi\" per aggiungere "
                "il tuo primo gioco PC o APK."
            )
            empty.setObjectName("PageSubtitle")
            self.row_layout.addWidget(empty)
            self.detail_title.setText("Nessun gioco selezionato")
            self.detail_meta.setText("")
            self.selected_game_id = None
        else:
            for game in games:
                tile = GameTile(game)
                tile.selected_signal.connect(self._select_game)
                tile.activated.connect(self._launch_game_id)
                self.row_layout.addWidget(tile)
                self.tiles.append(tile)

            if self.selected_game_id is None or not any(
                g["id"] == self.selected_game_id for g in games
            ):
                self.selected_game_id = games[0]["id"]
            self._select_game(self.selected_game_id, animate=False)

        stats = self.game_manager.stats()
        self.stats_label.setText(
            f"{stats['total']} giochi totali   ·   {stats['exe_count']} PC   ·   "
            f"{stats['apk_count']} Android   ·   {stats['installed']} installati"
        )

        if self.on_change:
            self.on_change()

    # ------------------------------------------------------------------ #
    def _select_game(self, game_id: int, animate: bool = True):
        self.selected_game_id = game_id
        for tile in self.tiles:
            tile.set_selected(tile.game["id"] == game_id, animate=animate)

        game = self.game_manager.get_game(game_id)
        if not game:
            return
        self.detail_title.setText(game["name"])
        tipo = "PC (EXE)" if game["type"] == "exe" else "Android (APK)"
        stato = "Installato" if game["installed"] else "Non installato"
        self.detail_meta.setText(f"{game.get('category', 'Generale')} · {tipo} · {stato}")

        # Colore dinamico dello sfondo in base al tipo di gioco selezionato
        accent = QColor(138, 43, 226) if game["type"] == "exe" else QColor(79, 172, 254)
        self.background.set_accent(accent)

    def _launch_game_id(self, game_id: int):
        self._select_game(game_id, animate=False)
        self._launch_selected()

    def _launch_selected(self):
        if self.selected_game_id is None:
            return
        game = self.game_manager.get_game(self.selected_game_id)
        if not game:
            return
        try:
            if game["type"] == "exe":
                self.game_manager.launch_exe(game["id"])
            else:
                if not game.get("package_name"):
                    QMessageBox.warning(
                        self, "Pacchetto mancante",
                        "Questo APK non ha un nome pacchetto impostato. "
                        "Installalo prima dalla sezione 'APK Android'."
                    )
                    return
                self.apk_manager.launch_package(game["package_name"])
                self.game_manager.register_play(game["id"])
            self.refresh()
        except (GameManagerError, ApkManagerError) as e:
            QMessageBox.critical(self, "Impossibile avviare", str(e))

    # ------------------------------------------------------------------ #
    def _on_tick(self):
        self.background.advance(ANIMATION_INTERVAL_MS)

    def keyPressEvent(self, event):
        if not self.tiles:
            super().keyPressEvent(event)
            return
        ids = [t.game["id"] for t in self.tiles]
        if self.selected_game_id not in ids:
            super().keyPressEvent(event)
            return
        idx = ids.index(self.selected_game_id)
        if event.key() == Qt.Key_Right and idx < len(ids) - 1:
            self._select_game(ids[idx + 1])
        elif event.key() == Qt.Key_Left and idx > 0:
            self._select_game(ids[idx - 1])
        elif event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self._launch_selected()
        else:
            super().keyPressEvent(event)
