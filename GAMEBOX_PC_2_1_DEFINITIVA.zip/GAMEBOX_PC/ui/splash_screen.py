"""
splash_screen.py
------------------
Schermata di avvio ("boot screen") animata, mostrata per un paio di
secondi prima della finestra principale: logo pulsante, anello di
caricamento rotante e barra di progresso, su sfondo nero/viola/blu.

Il ciclo di animazione gira a ~8 ms (~120 Hz) per la massima fluidita'
possibile; il risultato visivo reale dipende comunque dal monitor
dell'utente (capped a 60 Hz su schermi non a frequenza piu' alta).
"""

import math

from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QPainter, QColor, QFont, QPen, QRadialGradient
from PySide6.QtWidgets import QWidget

TICK_MS = 8           # ~120 Hz
BOOT_DURATION_MS = 1800


class SplashScreen(QWidget):
    finished = Signal()

    def __init__(self, parent=None):
        super().__init__(parent, Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground, False)
        self.resize(640, 400)
        self._center_on_screen()

        self._elapsed_ms = 0
        self._angle = 0.0

        self._timer = QTimer(self)
        self._timer.setInterval(TICK_MS)
        self._timer.timeout.connect(self._tick)

    def _center_on_screen(self):
        screen = self.screen()
        if screen:
            geo = screen.availableGeometry()
            self.move(
                geo.center().x() - self.width() // 2,
                geo.center().y() - self.height() // 2,
            )

    def start(self):
        self.show()
        self._timer.start()

    def _tick(self):
        self._elapsed_ms += TICK_MS
        self._angle = (self._angle + 4.0) % 360.0
        self.update()
        if self._elapsed_ms >= BOOT_DURATION_MS:
            self._timer.stop()
            self.finished.emit()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Sfondo
        painter.fillRect(self.rect(), QColor(8, 8, 14))

        cx, cy = self.width() / 2, self.height() / 2 - 20

        # Bagliore pulsante dietro al logo
        pulse = 0.5 + 0.5 * math.sin(self._elapsed_ms / 220.0)
        glow_radius = 140 + 20 * pulse
        glow = QRadialGradient(cx, cy, glow_radius)
        c1 = QColor(138, 43, 226)
        c1.setAlpha(int(90 * pulse + 40))
        c2 = QColor(138, 43, 226, 0)
        glow.setColorAt(0.0, c1)
        glow.setColorAt(1.0, c2)
        painter.setBrush(glow)
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(int(cx - glow_radius), int(cy - glow_radius),
                             int(glow_radius * 2), int(glow_radius * 2))

        # Anello di caricamento rotante (stile console moderna)
        ring_radius = 70
        pen = QPen(QColor(79, 172, 254))
        pen.setWidth(5)
        pen.setCapStyle(Qt.RoundCap)
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        span = 110 * 16  # QPainter usa 1/16 di grado
        start = int(self._angle * 16)
        painter.drawArc(int(cx - ring_radius), int(cy - ring_radius),
                         int(ring_radius * 2), int(ring_radius * 2), start, span)

        # Logo testuale
        painter.setPen(QColor(255, 255, 255))
        font = QFont("Segoe UI", 28, QFont.Bold)
        painter.setFont(font)
        painter.drawText(
            self.rect().adjusted(0, int(cy - self.height() / 2) + 40, 0, 0),
            Qt.AlignHCenter | Qt.AlignTop, "GAMEBOX"
        )
        sub_font = QFont("Segoe UI", 11)
        painter.setFont(sub_font)
        painter.setPen(QColor(79, 172, 254))
        painter.drawText(
            self.rect().adjusted(0, int(cy - self.height() / 2) + 85, 0, 0),
            Qt.AlignHCenter | Qt.AlignTop, "PC GAMING LAUNCHER"
        )

        # Barra di avanzamento in basso
        bar_w, bar_h = 360, 6
        bar_x = int(cx - bar_w / 2)
        bar_y = self.height() - 70
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor(30, 24, 48))
        painter.drawRoundedRect(bar_x, bar_y, bar_w, bar_h, 3, 3)

        progress = min(1.0, self._elapsed_ms / BOOT_DURATION_MS)
        painter.setBrush(QColor(138, 43, 226))
        painter.drawRoundedRect(bar_x, bar_y, int(bar_w * progress), bar_h, 3, 3)

        painter.setPen(QColor(138, 127, 176))
        painter.setFont(QFont("Segoe UI", 9))
        painter.drawText(
            bar_x, bar_y + 24, bar_w, 20, Qt.AlignHCenter, "Avvio in corso..."
        )
