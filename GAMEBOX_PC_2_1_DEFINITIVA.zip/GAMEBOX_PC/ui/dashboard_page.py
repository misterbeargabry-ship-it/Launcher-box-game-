"""
dashboard_page.py
-------------------
Dashboard iniziale: mostra statistiche della libreria (totale giochi,
giochi PC/Android, giochi piu' giocati, attivita' recente).
"""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QGridLayout, QSizePolicy
)


def _stat_card(value: str, label: str) -> QFrame:
    card = QFrame()
    card.setObjectName("StatCard")
    layout = QVBoxLayout(card)
    value_lbl = QLabel(value)
    value_lbl.setObjectName("StatValue")
    label_lbl = QLabel(label)
    label_lbl.setObjectName("StatLabel")
    layout.addWidget(value_lbl)
    layout.addWidget(label_lbl)
    return card


class DashboardPage(QWidget):
    def __init__(self, game_manager, apk_manager, parent=None):
        super().__init__(parent)
        self.game_manager = game_manager
        self.apk_manager = apk_manager
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(32, 24, 32, 24)
        self.main_layout.setSpacing(16)

        title = QLabel("Dashboard")
        title.setObjectName("PageTitle")
        subtitle = QLabel("Panoramica generale della tua libreria GAMEBOX PC")
        subtitle.setObjectName("PageSubtitle")
        self.main_layout.addWidget(title)
        self.main_layout.addWidget(subtitle)

        self.stats_row = QHBoxLayout()
        self.stats_row.setSpacing(16)
        self.main_layout.addLayout(self.stats_row)

        bottom_row = QHBoxLayout()
        bottom_row.setSpacing(16)

        self.recent_box = QFrame()
        self.recent_box.setObjectName("StatCard")
        self.recent_layout = QVBoxLayout(self.recent_box)
        bottom_row.addWidget(self.recent_box)

        self.top_box = QFrame()
        self.top_box.setObjectName("StatCard")
        self.top_layout = QVBoxLayout(self.top_box)
        bottom_row.addWidget(self.top_box)

        self.main_layout.addLayout(bottom_row)
        self.main_layout.addStretch()

    def refresh(self):
        # Pulisce la riga delle statistiche
        while self.stats_row.count():
            item = self.stats_row.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        stats = self.game_manager.stats()
        adb_ok = self.apk_manager.check_adb_available()
        device_ok = self.apk_manager.has_connected_device() if adb_ok else False

        self.stats_row.addWidget(_stat_card(str(stats["total"]), "Giochi totali"))
        self.stats_row.addWidget(_stat_card(str(stats["exe_count"]), "Giochi PC (EXE)"))
        self.stats_row.addWidget(_stat_card(str(stats["apk_count"]), "App Android (APK)"))
        self.stats_row.addWidget(_stat_card(str(stats["installed"]), "Installati"))
        self.stats_row.addWidget(_stat_card(
            "Connesso" if device_ok else ("ADB OK" if adb_ok else "Non disponibile"),
            "Stato Android"
        ))

        # Pulisce e ricostruisce la sezione "recenti"
        self._clear_layout(self.recent_layout)
        recent_title = QLabel("Giocati di recente")
        recent_title.setObjectName("GameCardTitle")
        self.recent_layout.addWidget(recent_title)
        if stats["recent"]:
            for item in stats["recent"]:
                lbl = QLabel(f"• {item['name']} — {item['last_played']}")
                lbl.setObjectName("GameCardMeta")
                self.recent_layout.addWidget(lbl)
        else:
            lbl = QLabel("Nessun gioco avviato finora.")
            lbl.setObjectName("GameCardMeta")
            self.recent_layout.addWidget(lbl)
        self.recent_layout.addStretch()

        self._clear_layout(self.top_layout)
        top_title = QLabel("Piu' giocati")
        top_title.setObjectName("GameCardTitle")
        self.top_layout.addWidget(top_title)
        if stats["most_played"] and any(m["play_count"] for m in stats["most_played"]):
            for item in stats["most_played"]:
                if item["play_count"] > 0:
                    lbl = QLabel(f"• {item['name']} — {item['play_count']} avvii")
                    lbl.setObjectName("GameCardMeta")
                    self.top_layout.addWidget(lbl)
        else:
            lbl = QLabel("Nessuna statistica disponibile ancora.")
            lbl.setObjectName("GameCardMeta")
            self.top_layout.addWidget(lbl)
        self.top_layout.addStretch()

    @staticmethod
    def _clear_layout(layout):
        while layout.count():
            item = layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
