"""
game_tile.py
-------------
Tile grande in stile "console" per la schermata Home: copertina ampia,
bordo luminoso animato quando selezionata, titolo che si illumina.
Pensata per una griglia orizzontale scorrevole (vedi ui/home_page.py).
"""

import os

from PySide6.QtCore import Qt, Signal, QPropertyAnimation, QEasingCurve, Property
from PySide6.QtGui import QPixmap, QPainter, QColor, QPen
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QSizePolicy

TILE_W, TILE_H = 220, 300


class GameTile(QWidget):
    activated = Signal(int)   # doppio click / invio -> avvia il gioco
    selected_signal = Signal(int)  # click singolo / focus -> seleziona

    def __init__(self, game: dict, parent=None):
        super().__init__(parent)
        self.game = game
        self._glow = 0.0  # 0 = non selezionata, 1 = selezionata (animato)
        self._is_selected = False
        self.setFixedSize(TILE_W, TILE_H)
        self.setCursor(Qt.PointingHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)

        self._anim = QPropertyAnimation(self, b"glow")
        self._anim.setDuration(180)
        self._anim.setEasingCurve(QEasingCurve.OutCubic)

        self._build_ui()

    # ------------------------------------------------------------------ #
    # Proprieta' Qt animabile: intensita' del bordo luminoso (0.0 -> 1.0)
    def get_glow(self):
        return self._glow

    def set_glow(self, value):
        self._glow = value
        self.update()

    glow = Property(float, get_glow, set_glow)

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(6)

        self.cover_label = QLabel()
        self.cover_label.setFixedSize(TILE_W - 20, TILE_H - 70)
        self.cover_label.setAlignment(Qt.AlignCenter)
        self.cover_label.setStyleSheet(
            "background-color: #15111f; border-radius: 10px; color: #4facfe;"
        )
        cover_path = self.game.get("cover_path")
        if cover_path and os.path.isfile(cover_path):
            pixmap = QPixmap(cover_path)
            if not pixmap.isNull():
                pixmap = pixmap.scaled(
                    self.cover_label.width(), self.cover_label.height(),
                    Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation,
                )
                self.cover_label.setPixmap(pixmap)
        else:
            icon = "🎮" if self.game.get("type") == "exe" else "📱"
            self.cover_label.setText(f"{icon}\n{self.game.get('name', '')[:16]}")
        layout.addWidget(self.cover_label)

        self.title_label = QLabel(self.game.get("name", ""))
        self.title_label.setAlignment(Qt.AlignCenter)
        self.title_label.setWordWrap(True)
        self.title_label.setStyleSheet("color: #e6e6f0; font-weight: bold; font-size: 13px;")
        layout.addWidget(self.title_label)

        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

    # ------------------------------------------------------------------ #
    def set_selected(self, selected: bool, animate: bool = True):
        self._is_selected = selected
        target = 1.0 if selected else 0.0
        if animate:
            self._anim.stop()
            self._anim.setStartValue(self._glow)
            self._anim.setEndValue(target)
            self._anim.start()
        else:
            self.set_glow(target)
        if selected:
            self.title_label.setStyleSheet(
                "color: #ffffff; font-weight: bold; font-size: 15px;"
            )
            self.setFocus()
        else:
            self.title_label.setStyleSheet(
                "color: #e6e6f0; font-weight: bold; font-size: 13px;"
            )

    def paintEvent(self, event):
        super().paintEvent(event)
        if self._glow <= 0.001:
            return
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Bordo luminoso viola -> blu elettrico, intensita' proporzionale a _glow
        alpha = int(255 * self._glow)
        color = QColor(138, 43, 226, alpha)  # #8a2be2 con alpha animato
        pen = QPen(color)
        pen.setWidth(3)
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        rect = self.rect().adjusted(2, 2, -2, -2)
        painter.drawRoundedRect(rect, 14, 14)

        # Leggero bagliore esterno aggiuntivo quando completamente selezionata
        if self._glow > 0.5:
            outer_alpha = int(90 * (self._glow - 0.5) * 2)
            glow_color = QColor(79, 172, 254, outer_alpha)
            pen2 = QPen(glow_color)
            pen2.setWidth(6)
            painter.setPen(pen2)
            painter.drawRoundedRect(self.rect().adjusted(0, 0, -1, -1), 16, 16)

    # ------------------------------------------------------------------ #
    def mousePressEvent(self, event):
        self.selected_signal.emit(self.game["id"])
        super().mousePressEvent(event)

    def mouseDoubleClickEvent(self, event):
        self.activated.emit(self.game["id"])
        super().mouseDoubleClickEvent(event)

    def keyPressEvent(self, event):
        if event.key() in (Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self.activated.emit(self.game["id"])
        else:
            super().keyPressEvent(event)
