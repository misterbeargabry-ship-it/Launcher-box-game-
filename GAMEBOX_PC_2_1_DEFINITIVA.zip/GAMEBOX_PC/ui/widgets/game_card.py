"""
game_card.py
-------------
Widget che rappresenta la "copertina" di un singolo gioco nella libreria:
mostra immagine (o placeholder), nome, categoria/tipo e pulsanti Avvia/Elimina.
"""

import os

from PySide6.QtCore import Qt, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QSizePolicy
)

COVER_W, COVER_H = 160, 210


class GameCard(QWidget):
    launch_requested = Signal(int)
    delete_requested = Signal(int)
    shortcut_requested = Signal(int)

    def __init__(self, game: dict, parent=None):
        super().__init__(parent)
        self.game = game
        self.setObjectName("GameCard")
        self.setFixedWidth(COVER_W + 24)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(6)

        cover_label = QLabel()
        cover_label.setFixedSize(COVER_W, COVER_H)
        cover_label.setAlignment(Qt.AlignCenter)
        cover_label.setStyleSheet(
            "background-color: #1a1430; border-radius: 8px; color: #4facfe; "
            "font-size: 12px; border: 1px solid #241a3d;"
        )
        cover_path = self.game.get("cover_path")
        if cover_path and os.path.isfile(cover_path):
            pixmap = QPixmap(cover_path)
            if not pixmap.isNull():
                pixmap = pixmap.scaled(
                    COVER_W, COVER_H, Qt.KeepAspectRatioByExpanding,
                    Qt.SmoothTransformation,
                )
                cover_label.setPixmap(pixmap)
            else:
                cover_label.setText("Nessuna\ncopertina")
        else:
            icon = "🎮" if self.game.get("type") == "exe" else "📱"
            cover_label.setText(f"{icon}\n{self.game.get('name', '')[:18]}")
        layout.addWidget(cover_label)

        title = QLabel(self.game.get("name", "Senza nome"))
        title.setObjectName("GameCardTitle")
        title.setWordWrap(True)
        layout.addWidget(title)

        tipo = "PC (EXE)" if self.game.get("type") == "exe" else "Android (APK)"
        stato = "Installato" if self.game.get("installed") else "Non installato"
        meta = QLabel(f"{self.game.get('category', 'Generale')} · {tipo}\n{stato}")
        meta.setObjectName("GameCardMeta")
        meta.setWordWrap(True)
        layout.addWidget(meta)

        btn_row = QHBoxLayout()
        play_btn = QPushButton("▶ Avvia")
        play_btn.setObjectName("PrimaryButton")
        play_btn.clicked.connect(lambda: self.launch_requested.emit(self.game["id"]))
        btn_row.addWidget(play_btn)

        del_btn = QPushButton("🗑")
        del_btn.setFixedWidth(36)
        del_btn.setObjectName("DangerButton")
        del_btn.setToolTip("Elimina dalla libreria")
        del_btn.clicked.connect(lambda: self.delete_requested.emit(self.game["id"]))
        btn_row.addWidget(del_btn)
        layout.addLayout(btn_row)

        if self.game.get("type") == "exe":
            shortcut_btn = QPushButton("Crea collegamento rapido")
            shortcut_btn.clicked.connect(
                lambda: self.shortcut_requested.emit(self.game["id"])
            )
            layout.addWidget(shortcut_btn)

        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
