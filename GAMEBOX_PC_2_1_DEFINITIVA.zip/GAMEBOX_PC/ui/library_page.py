"""
library_page.py
------------------
Pagina principale della libreria: griglia di copertine, ricerca, filtro per
categoria, aggiunta di giochi EXE/APK, rilevamento app Windows installate,
eliminazione ed avvio dei giochi.
"""

import os
import subprocess
import sys

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QLabel, QLineEdit,
    QPushButton, QComboBox, QScrollArea, QFileDialog, QMessageBox,
    QInputDialog, QDialog, QFormLayout, QDialogButtonBox
)

from game_manager import GameManagerError
from apk_manager import ApkManagerError
from ui.widgets.game_card import GameCard


class AddExeDialog(QDialog):
    """Finestra per aggiungere manualmente un gioco PC (.exe)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Aggiungi gioco PC (EXE)")
        self.setMinimumWidth(420)
        self.exe_path = ""
        self.cover_path = ""

        layout = QFormLayout(self)

        self.name_edit = QLineEdit()
        layout.addRow("Nome gioco:", self.name_edit)

        exe_row = QHBoxLayout()
        self.exe_label = QLabel("Nessun file selezionato")
        exe_btn = QPushButton("Sfoglia...")
        exe_btn.clicked.connect(self._pick_exe)
        exe_row.addWidget(self.exe_label, 1)
        exe_row.addWidget(exe_btn)
        layout.addRow("File eseguibile (.exe):", exe_row)

        cover_row = QHBoxLayout()
        self.cover_label = QLabel("Nessuna copertina")
        cover_btn = QPushButton("Sfoglia...")
        cover_btn.clicked.connect(self._pick_cover)
        cover_row.addWidget(self.cover_label, 1)
        cover_row.addWidget(cover_btn)
        layout.addRow("Copertina (opzionale):", cover_row)

        self.category_edit = QLineEdit("Generale")
        layout.addRow("Categoria:", self.category_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def _pick_exe(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleziona eseguibile", "", "Eseguibili Windows (*.exe)"
        )
        if path:
            self.exe_path = path
            self.exe_label.setText(os.path.basename(path))
            if not self.name_edit.text():
                self.name_edit.setText(os.path.splitext(os.path.basename(path))[0])

    def _pick_cover(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleziona copertina", "", "Immagini (*.png *.jpg *.jpeg *.webp)"
        )
        if path:
            self.cover_path = path
            self.cover_label.setText(os.path.basename(path))


class AddApkDialog(QDialog):
    """Finestra per importare un file APK."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Importa APK Android")
        self.setMinimumWidth(420)
        self.apk_path = ""
        self.cover_path = ""

        layout = QFormLayout(self)

        self.name_edit = QLineEdit()
        layout.addRow("Nome app/gioco:", self.name_edit)

        apk_row = QHBoxLayout()
        self.apk_label = QLabel("Nessun file selezionato")
        apk_btn = QPushButton("Sfoglia...")
        apk_btn.clicked.connect(self._pick_apk)
        apk_row.addWidget(self.apk_label, 1)
        apk_row.addWidget(apk_btn)
        layout.addRow("File APK:", apk_row)

        self.package_edit = QLineEdit()
        self.package_edit.setPlaceholderText("com.azienda.gioco (rilevato automaticamente se possibile)")
        layout.addRow("Nome pacchetto:", self.package_edit)

        cover_row = QHBoxLayout()
        self.cover_label = QLabel("Nessuna copertina")
        cover_btn = QPushButton("Sfoglia...")
        cover_btn.clicked.connect(self._pick_cover)
        cover_row.addWidget(self.cover_label, 1)
        cover_row.addWidget(cover_btn)
        layout.addRow("Copertina (opzionale):", cover_row)

        self.category_edit = QLineEdit("Android")
        layout.addRow("Categoria:", self.category_edit)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

    def _pick_apk(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleziona APK", "", "Pacchetti Android (*.apk)"
        )
        if path:
            self.apk_path = path
            self.apk_label.setText(os.path.basename(path))
            if not self.name_edit.text():
                self.name_edit.setText(os.path.splitext(os.path.basename(path))[0])

    def _pick_cover(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleziona copertina", "", "Immagini (*.png *.jpg *.jpeg *.webp)"
        )
        if path:
            self.cover_path = path
            self.cover_label.setText(os.path.basename(path))


class LibraryPage(QWidget):
    def __init__(self, game_manager, apk_manager, on_change=None, parent=None):
        super().__init__(parent)
        self.game_manager = game_manager
        self.apk_manager = apk_manager
        self.on_change = on_change  # callback per aggiornare altre pagine (es. dashboard)
        self._build_ui()
        self.refresh()

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 24, 32, 24)
        layout.setSpacing(16)

        title = QLabel("Libreria Giochi")
        title.setObjectName("PageTitle")
        subtitle = QLabel("Gestisci, cerca e avvia i tuoi giochi PC e Android")
        subtitle.setObjectName("PageSubtitle")
        layout.addWidget(title)
        layout.addWidget(subtitle)

        toolbar = QHBoxLayout()
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("Cerca un gioco...")
        self.search_edit.textChanged.connect(self.refresh)
        toolbar.addWidget(self.search_edit, 2)

        self.category_combo = QComboBox()
        self.category_combo.currentTextChanged.connect(self.refresh)
        toolbar.addWidget(self.category_combo, 1)

        add_exe_btn = QPushButton("+ Aggiungi EXE")
        add_exe_btn.setObjectName("PrimaryButton")
        add_exe_btn.clicked.connect(self._add_exe)
        toolbar.addWidget(add_exe_btn)

        add_apk_btn = QPushButton("+ Importa APK")
        add_apk_btn.clicked.connect(self._add_apk)
        toolbar.addWidget(add_apk_btn)

        detect_btn = QPushButton("Rileva app installate")
        detect_btn.clicked.connect(self._detect_installed)
        toolbar.addWidget(detect_btn)

        layout.addLayout(toolbar)

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setFrameShape(QScrollArea.NoFrame)
        self.grid_container = QWidget()
        self.grid_layout = QGridLayout(self.grid_container)
        self.grid_layout.setSpacing(16)
        self.grid_layout.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.scroll_area.setWidget(self.grid_container)
        layout.addWidget(self.scroll_area, 1)

        self.empty_label = QLabel(
            "La tua libreria e' vuota. Usa \"Aggiungi EXE\" o \"Importa APK\" per iniziare."
        )
        self.empty_label.setObjectName("PageSubtitle")
        self.empty_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.empty_label)

    # ------------------------------------------------------------------ #
    def refresh(self):
        # Aggiorna elenco categorie mantenendo la selezione corrente se possibile
        current_cat = self.category_combo.currentText() or "Tutte"
        self.category_combo.blockSignals(True)
        self.category_combo.clear()
        categories = ["Tutte"] + self.game_manager.list_categories()
        self.category_combo.addItems(categories)
        idx = self.category_combo.findText(current_cat)
        self.category_combo.setCurrentIndex(idx if idx >= 0 else 0)
        self.category_combo.blockSignals(False)

        search = self.search_edit.text().strip()
        category = self.category_combo.currentText()
        games = self.game_manager.list_games(category=category, search=search)

        # Svuota la griglia
        while self.grid_layout.count():
            item = self.grid_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        self.empty_label.setVisible(len(games) == 0)

        columns = 5
        for index, game in enumerate(games):
            card = GameCard(game)
            card.launch_requested.connect(self._launch_game)
            card.delete_requested.connect(self._delete_game)
            card.shortcut_requested.connect(self._create_shortcut)
            row, col = divmod(index, columns)
            self.grid_layout.addWidget(card, row, col)

        if self.on_change:
            self.on_change()

    # ------------------------------------------------------------------ #
    def _add_exe(self):
        dialog = AddExeDialog(self)
        if dialog.exec() == QDialog.Accepted:
            if not dialog.exe_path:
                QMessageBox.warning(self, "Attenzione", "Devi selezionare un file .exe.")
                return
            try:
                self.game_manager.add_exe_game(
                    name=dialog.name_edit.text() or os.path.basename(dialog.exe_path),
                    exe_path=dialog.exe_path,
                    cover_path=dialog.cover_path or None,
                    category=dialog.category_edit.text() or "Generale",
                )
                self.refresh()
            except GameManagerError as e:
                QMessageBox.critical(self, "Errore", str(e))

    def _add_apk(self):
        dialog = AddApkDialog(self)
        if dialog.exec() == QDialog.Accepted:
            if not dialog.apk_path:
                QMessageBox.warning(self, "Attenzione", "Devi selezionare un file .apk.")
                return
            try:
                imported_path = self.apk_manager.import_apk(dialog.apk_path)
                package_name = dialog.package_edit.text().strip() or \
                    self.apk_manager.guess_package_name(imported_path)
                self.game_manager.add_apk_entry(
                    name=dialog.name_edit.text() or os.path.basename(dialog.apk_path),
                    apk_path=imported_path,
                    package_name=package_name,
                    cover_path=dialog.cover_path or None,
                    category=dialog.category_edit.text() or "Android",
                )
                self.refresh()
            except (ApkManagerError, GameManagerError) as e:
                QMessageBox.critical(self, "Errore", str(e))

    def _detect_installed(self):
        if sys.platform != "win32":
            QMessageBox.information(
                self, "Non disponibile",
                "Il rilevamento delle applicazioni installate funziona solo "
                "su Windows (legge il registro di sistema)."
            )
            return
        apps = self.game_manager.detect_installed_windows_apps()
        if not apps:
            QMessageBox.information(self, "Rilevamento", "Nessuna applicazione trovata.")
            return
        names = [a["name"] for a in apps]
        choice, ok = QInputDialog.getItem(
            self, "App installate rilevate",
            f"Trovate {len(apps)} applicazioni. Seleziona quella da aggiungere:",
            names, 0, False,
        )
        if ok and choice:
            app = next(a for a in apps if a["name"] == choice)
            try:
                self.game_manager.add_exe_game(
                    name=app["name"], exe_path=app["path"], category="Importati"
                )
                self.refresh()
            except GameManagerError as e:
                QMessageBox.critical(self, "Errore", str(e))

    def _launch_game(self, game_id: int):
        game = self.game_manager.get_game(game_id)
        if not game:
            return
        try:
            if game["type"] == "exe":
                self.game_manager.launch_exe(game_id)
                self.refresh()
            else:
                if not game.get("package_name"):
                    QMessageBox.warning(
                        self, "Pacchetto mancante",
                        "Questo APK non ha un nome pacchetto impostato. "
                        "Installalo prima dalla sezione 'APK Android'."
                    )
                    return
                self.apk_manager.launch_package(game["package_name"])
                self.game_manager.register_play(game_id)
                self.refresh()
        except (GameManagerError, ApkManagerError) as e:
            QMessageBox.critical(self, "Impossibile avviare", str(e))

    def _delete_game(self, game_id: int):
        reply = QMessageBox.question(
            self, "Conferma eliminazione",
            "Rimuovere questo gioco dalla libreria? Il file originale non verra' cancellato.",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            self.game_manager.remove_game(game_id)
            self.refresh()

    def _create_shortcut(self, game_id: int):
        try:
            path = self.game_manager.create_shortcut(game_id)
            QMessageBox.information(self, "Collegamento creato", f"Creato in:\n{path}")
        except GameManagerError as e:
            QMessageBox.critical(self, "Errore", str(e))
