"""
settings_page.py
-------------------
Pagina Impostazioni: risoluzione interfaccia, tema, lingua, percorsi di
libreria/APK/download, configurazione ADB/emulatore Android e supporto
controller.
"""

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QLabel, QLineEdit,
    QPushButton, QComboBox, QCheckBox, QFileDialog, QMessageBox, QFrame
)

try:
    import pygame
    PYGAME_AVAILABLE = True
except ImportError:
    PYGAME_AVAILABLE = False


class SettingsPage(QWidget):
    def __init__(self, settings, on_settings_changed=None, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.on_settings_changed = on_settings_changed
        self._build_ui()
        self._load_values()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 24, 32, 24)
        layout.setSpacing(16)

        title = QLabel("Impostazioni")
        title.setObjectName("PageTitle")
        subtitle = QLabel("Personalizza GAMEBOX PC in base al tuo sistema")
        subtitle.setObjectName("PageSubtitle")
        layout.addWidget(title)
        layout.addWidget(subtitle)

        form_frame = QFrame()
        form_frame.setObjectName("StatCard")
        form = QFormLayout(form_frame)
        form.setSpacing(12)

        self.resolution_combo = QComboBox()
        self.resolution_combo.addItems(
            ["1280x720", "1366x768", "1600x900", "1920x1080", "2560x1440"]
        )
        form.addRow("Risoluzione interfaccia:", self.resolution_combo)

        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Scuro Blu/Viola"])
        form.addRow("Tema grafico:", self.theme_combo)

        self.language_combo = QComboBox()
        self.language_combo.addItems(["Italiano"])
        form.addRow("Lingua:", self.language_combo)

        self.library_path_edit, library_row = self._path_row(self._browse_library)
        form.addRow("Percorso libreria giochi:", library_row)

        self.apk_path_edit, apk_row = self._path_row(self._browse_apk)
        form.addRow("Percorso APK importati:", apk_row)

        self.downloads_path_edit, downloads_row = self._path_row(self._browse_downloads)
        form.addRow("Percorso download:", downloads_row)

        layout.addWidget(form_frame)

        android_frame = QFrame()
        android_frame.setObjectName("StatCard")
        android_form = QFormLayout(android_frame)
        android_label = QLabel("Configurazione Android / ADB")
        android_label.setObjectName("GameCardTitle")
        android_form.addRow(android_label)

        self.adb_path_edit = QLineEdit()
        self.adb_path_edit.setPlaceholderText("adb (oppure percorso completo a adb.exe)")
        android_form.addRow("Percorso ADB:", self.adb_path_edit)

        self.aapt_path_edit = QLineEdit()
        self.aapt_path_edit.setPlaceholderText("aapt (opzionale, per rilevare il package name)")
        android_form.addRow("Percorso aapt (opzionale):", self.aapt_path_edit)

        self.emulator_path_edit, emulator_row = self._path_row(self._browse_emulator, is_file=True)
        android_form.addRow("Eseguibile emulatore Android:", emulator_row)

        launch_emu_btn = QPushButton("Avvia emulatore")
        launch_emu_btn.clicked.connect(self._launch_emulator)
        android_form.addRow("", launch_emu_btn)

        layout.addWidget(android_frame)

        controller_frame = QFrame()
        controller_frame.setObjectName("StatCard")
        controller_layout = QVBoxLayout(controller_frame)
        controller_label = QLabel("Controller / Gamepad")
        controller_label.setObjectName("GameCardTitle")
        controller_layout.addWidget(controller_label)

        self.controller_checkbox = QCheckBox("Abilita supporto controller")
        controller_layout.addWidget(self.controller_checkbox)

        controller_test_row = QHBoxLayout()
        test_btn = QPushButton("Rileva controller collegati")
        test_btn.clicked.connect(self._test_controller)
        controller_test_row.addWidget(test_btn)
        self.controller_status = QLabel(
            "pygame non installato: installa 'pygame' per il supporto controller."
            if not PYGAME_AVAILABLE else "Nessun test eseguito."
        )
        self.controller_status.setObjectName("GameCardMeta")
        controller_test_row.addWidget(self.controller_status, 1)
        controller_layout.addLayout(controller_test_row)

        layout.addWidget(controller_frame)

        save_row = QHBoxLayout()
        save_row.addStretch()
        save_btn = QPushButton("Salva impostazioni")
        save_btn.setObjectName("PrimaryButton")
        save_btn.clicked.connect(self._save)
        save_row.addWidget(save_btn)
        layout.addLayout(save_row)

        layout.addStretch()

    def _path_row(self, browse_callback, is_file=False):
        edit = QLineEdit()
        row_widget = QHBoxLayout()
        row_widget.addWidget(edit, 1)
        btn = QPushButton("Sfoglia...")
        btn.clicked.connect(lambda: browse_callback(edit))
        row_widget.addWidget(btn)
        container = QWidget()
        container.setLayout(row_widget)
        return edit, container

    # ------------------------------------------------------------------ #
    def _load_values(self):
        self.resolution_combo.setCurrentText(self.settings.get("resolution", "1600x900"))
        self.library_path_edit.setText(self.settings.get("library_path", ""))
        self.apk_path_edit.setText(self.settings.get("apk_path", ""))
        self.downloads_path_edit.setText(self.settings.get("downloads_path", ""))
        self.adb_path_edit.setText(self.settings.get("adb_path", "adb"))
        self.aapt_path_edit.setText(self.settings.get("aapt_path", "aapt"))
        self.emulator_path_edit.setText(self.settings.get("emulator_path", ""))
        self.controller_checkbox.setChecked(bool(self.settings.get("controller_enabled", True)))

    def _browse_library(self, edit):
        path = QFileDialog.getExistingDirectory(self, "Scegli cartella libreria")
        if path:
            edit.setText(path)

    def _browse_apk(self, edit):
        path = QFileDialog.getExistingDirectory(self, "Scegli cartella APK")
        if path:
            edit.setText(path)

    def _browse_downloads(self, edit):
        path = QFileDialog.getExistingDirectory(self, "Scegli cartella download")
        if path:
            edit.setText(path)

    def _browse_emulator(self, edit):
        path, _ = QFileDialog.getOpenFileName(
            self, "Seleziona eseguibile emulatore", "", "Eseguibili (*.exe);;Tutti i file (*)"
        )
        if path:
            edit.setText(path)

    def _launch_emulator(self):
        import os
        import subprocess
        import sys

        path = self.emulator_path_edit.text().strip()
        if not path or not os.path.isfile(path):
            QMessageBox.warning(self, "Percorso non valido",
                                 "Imposta un percorso valido per l'emulatore.")
            return
        try:
            subprocess.Popen([path])
            QMessageBox.information(self, "Avvio emulatore",
                                     "Richiesta di avvio inviata all'emulatore.")
        except OSError as e:
            QMessageBox.critical(self, "Errore", f"Impossibile avviare l'emulatore: {e}")

    def _test_controller(self):
        if not PYGAME_AVAILABLE:
            QMessageBox.information(
                self, "Supporto controller non disponibile",
                "Installa il pacchetto 'pygame' (pip install pygame) per abilitare "
                "il rilevamento dei controller."
            )
            return
        try:
            pygame.init()
            pygame.joystick.init()
            count = pygame.joystick.get_count()
            if count == 0:
                self.controller_status.setText("Nessun controller rilevato.")
            else:
                names = []
                for i in range(count):
                    joy = pygame.joystick.Joystick(i)
                    joy.init()
                    names.append(joy.get_name())
                self.controller_status.setText(f"Rilevati {count}: {', '.join(names)}")
        except pygame.error as e:
            self.controller_status.setText(f"Errore controller: {e}")
        finally:
            pygame.joystick.quit()
            pygame.quit()

    def _save(self):
        self.settings.set_many({
            "resolution": self.resolution_combo.currentText(),
            "theme": self.theme_combo.currentText(),
            "language": self.language_combo.currentText(),
            "library_path": self.library_path_edit.text().strip() or self.settings.get("library_path"),
            "apk_path": self.apk_path_edit.text().strip() or self.settings.get("apk_path"),
            "downloads_path": self.downloads_path_edit.text().strip() or self.settings.get("downloads_path"),
            "adb_path": self.adb_path_edit.text().strip() or "adb",
            "aapt_path": self.aapt_path_edit.text().strip() or "aapt",
            "emulator_path": self.emulator_path_edit.text().strip(),
            "controller_enabled": self.controller_checkbox.isChecked(),
        })
        self.settings.save()
        QMessageBox.information(
            self, "Impostazioni salvate",
            "Le impostazioni sono state salvate. Alcune modifiche (come la "
            "risoluzione) richiedono il riavvio di GAMEBOX PC."
        )
        if self.on_settings_changed:
            self.on_settings_changed()
