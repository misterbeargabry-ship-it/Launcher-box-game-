"""
main_window.py
----------------
Finestra principale di GAMEBOX PC: menu laterale (sidebar) e area
contenuti con le varie pagine (Dashboard, Libreria, APK Android, Download,
Impostazioni) gestite tramite QStackedWidget.
"""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QStackedWidget, QButtonGroup
)

from ui.home_page import HomePage
from ui.dashboard_page import DashboardPage
from ui.library_page import LibraryPage
from ui.apk_page import ApkPage
from ui.download_page import DownloadPage
from ui.settings_page import SettingsPage


class MainWindow(QMainWindow):
    def __init__(self, settings, game_manager, apk_manager, download_manager):
        super().__init__()
        self.settings = settings
        self.game_manager = game_manager
        self.apk_manager = apk_manager
        self.download_manager = download_manager

        self.setWindowTitle("GAMEBOX PC")
        w, h = settings.resolution_tuple()
        self.resize(w, h)
        self.setMinimumSize(1024, 650)

        self._build_ui()

    # ------------------------------------------------------------------ #
    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root_layout = QHBoxLayout(central)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)

        sidebar = self._build_sidebar()
        root_layout.addWidget(sidebar)

        self.stack = QStackedWidget()
        root_layout.addWidget(self.stack, 1)

        self.home_page = HomePage(
            self.game_manager, self.apk_manager, on_change=self._refresh_dashboard
        )
        self.dashboard_page = DashboardPage(self.game_manager, self.apk_manager)
        self.library_page = LibraryPage(
            self.game_manager, self.apk_manager, on_change=self._refresh_home_and_dashboard
        )
        self.apk_page = ApkPage(
            self.game_manager, self.apk_manager, on_change=self._refresh_home_and_dashboard
        )
        self.download_page = DownloadPage(self.download_manager)
        self.settings_page = SettingsPage(
            self.settings, on_settings_changed=self._on_settings_changed
        )

        self.stack.addWidget(self.home_page)          # indice 0
        self.stack.addWidget(self.dashboard_page)     # indice 1
        self.stack.addWidget(self.library_page)       # indice 2
        self.stack.addWidget(self.apk_page)            # indice 3
        self.stack.addWidget(self.download_page)       # indice 4
        self.stack.addWidget(self.settings_page)       # indice 5

        self.nav_buttons[0].setChecked(True)

    def _build_sidebar(self) -> QWidget:
        sidebar = QWidget()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(230)
        layout = QVBoxLayout(sidebar)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        title = QLabel("GAMEBOX")
        title.setObjectName("SidebarTitle")
        layout.addWidget(title)

        subtitle = QLabel("PC GAMING LAUNCHER")
        subtitle.setObjectName("SidebarSubtitle")
        layout.addWidget(subtitle)

        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)
        self.nav_buttons = []

        nav_items = [
            ("🏠  Home", 0),
            ("📊  Dashboard", 1),
            ("🎮  Libreria Giochi", 2),
            ("📱  APK Android", 3),
            ("⬇  Download", 4),
            ("⚙  Impostazioni", 5),
        ]

        for text, index in nav_items:
            btn = QPushButton(text)
            btn.setObjectName("NavButton")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.clicked.connect(lambda _, i=index: self._switch_page(i))
            self.nav_group.addButton(btn)
            self.nav_buttons.append(btn)
            layout.addWidget(btn)

        layout.addStretch()

        version_label = QLabel("v2.0")
        version_label.setObjectName("SidebarSubtitle")
        version_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(version_label)

        return sidebar

    # ------------------------------------------------------------------ #
    def _switch_page(self, index: int):
        self.stack.setCurrentIndex(index)
        if index == 0:
            self.home_page.refresh()
        elif index == 1:
            self.dashboard_page.refresh()
        elif index == 2:
            self.library_page.refresh()
        elif index == 3:
            self.apk_page.refresh()
        elif index == 4:
            self.download_page.refresh()

    def _refresh_dashboard(self):
        self.dashboard_page.refresh()

    def _refresh_home_and_dashboard(self):
        self.home_page.refresh()
        self.dashboard_page.refresh()

    def _on_settings_changed(self):
        self.home_page.refresh()
        self.library_page.refresh()
        self.apk_page.refresh()
        self.dashboard_page.refresh()
