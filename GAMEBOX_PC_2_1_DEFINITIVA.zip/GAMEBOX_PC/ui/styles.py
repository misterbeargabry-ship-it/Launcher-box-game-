"""
styles.py
----------
Tema grafico "premium e futuristico" di GAMEBOX PC: nero profondo con
accenti blu elettrico e viola, tipico delle interfacce gaming moderne.
"""

DARK_PURPLE_BLUE_THEME = """
QWidget {
    background-color: #0a0a12;
    color: #e6e6f0;
    font-family: "Segoe UI", "Arial", sans-serif;
    font-size: 14px;
}

QMainWindow {
    background-color: #0a0a12;
}

/* ---------- Barra laterale ---------- */
#Sidebar {
    background-color: #0d0d18;
    border-right: 1px solid #241a3d;
}

#SidebarTitle {
    color: #8a2be2;
    font-size: 20px;
    font-weight: bold;
    padding: 24px 16px 8px 16px;
    letter-spacing: 2px;
}

#SidebarSubtitle {
    color: #4facfe;
    font-size: 11px;
    padding: 0px 16px 20px 16px;
    letter-spacing: 1px;
}

QPushButton#NavButton {
    text-align: left;
    padding: 12px 20px;
    border: none;
    border-left: 3px solid transparent;
    background-color: transparent;
    color: #b8b8d0;
    font-size: 14px;
    font-weight: 500;
}

QPushButton#NavButton:hover {
    background-color: #1a1430;
    color: #ffffff;
}

QPushButton#NavButton:checked {
    background-color: #1a1430;
    border-left: 3px solid #8a2be2;
    color: #4facfe;
    font-weight: bold;
}

/* ---------- Pulsanti generali ---------- */
QPushButton {
    background-color: #1a1430;
    color: #e6e6f0;
    border: 1px solid #3d2e66;
    border-radius: 8px;
    padding: 9px 18px;
    font-weight: 600;
}

QPushButton:hover {
    background-color: #2a1f52;
    border: 1px solid #8a2be2;
    color: #ffffff;
}

QPushButton:pressed {
    background-color: #4facfe;
    color: #0a0a12;
}

QPushButton:disabled {
    background-color: #15121f;
    color: #55506a;
    border: 1px solid #241a3d;
}

QPushButton#PrimaryButton {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                       stop:0 #8a2be2, stop:1 #4facfe);
    color: #ffffff;
    border: none;
}

QPushButton#PrimaryButton:hover {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                       stop:0 #9b3ff5, stop:1 #62baff);
}

QPushButton#DangerButton {
    background-color: #3d0e1f;
    border: 1px solid #ff3860;
    color: #ff7a93;
}

QPushButton#DangerButton:hover {
    background-color: #5c1230;
    color: #ffffff;
}

/* ---------- Campi di testo / combo ---------- */
QLineEdit, QComboBox, QSpinBox {
    background-color: #15121f;
    border: 1px solid #3d2e66;
    border-radius: 6px;
    padding: 8px 10px;
    color: #e6e6f0;
    selection-background-color: #8a2be2;
}

QLineEdit:focus, QComboBox:focus {
    border: 1px solid #4facfe;
}

QComboBox::drop-down {
    border: none;
}

QComboBox QAbstractItemView {
    background-color: #15121f;
    border: 1px solid #3d2e66;
    selection-background-color: #2a1f52;
    color: #e6e6f0;
}

/* ---------- Schede / card ---------- */
#GameCard {
    background-color: #12101e;
    border: 1px solid #241a3d;
    border-radius: 12px;
}

#GameCard:hover {
    border: 1px solid #8a2be2;
}

#GameCardTitle {
    font-weight: bold;
    font-size: 14px;
    color: #ffffff;
}

#GameCardMeta {
    color: #8a7fb0;
    font-size: 11px;
}

#StatCard {
    background-color: #12101e;
    border: 1px solid #241a3d;
    border-radius: 12px;
    padding: 16px;
}

#StatValue {
    font-size: 28px;
    font-weight: bold;
    color: #4facfe;
}

#StatLabel {
    color: #9a93b5;
    font-size: 12px;
}

/* ---------- Titoli di pagina ---------- */
#PageTitle {
    font-size: 24px;
    font-weight: bold;
    color: #ffffff;
    padding-bottom: 4px;
}

#PageSubtitle {
    color: #8a7fb0;
    font-size: 13px;
    padding-bottom: 12px;
}

/* ---------- Tabelle / liste ---------- */
QTableWidget, QListWidget {
    background-color: #12101e;
    border: 1px solid #241a3d;
    border-radius: 8px;
    gridline-color: #241a3d;
}

QHeaderView::section {
    background-color: #1a1430;
    color: #b8b8d0;
    padding: 8px;
    border: none;
    border-bottom: 1px solid #3d2e66;
}

QTableWidget::item:selected, QListWidget::item:selected {
    background-color: #2a1f52;
    color: #ffffff;
}

/* ---------- Barre di avanzamento ---------- */
QProgressBar {
    background-color: #15121f;
    border: 1px solid #3d2e66;
    border-radius: 6px;
    text-align: center;
    color: #e6e6f0;
    height: 18px;
}

QProgressBar::chunk {
    background-color: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                                       stop:0 #8a2be2, stop:1 #4facfe);
    border-radius: 6px;
}

/* ---------- Scrollbar ---------- */
QScrollBar:vertical {
    background: #0a0a12;
    width: 10px;
}

QScrollBar::handle:vertical {
    background: #3d2e66;
    border-radius: 5px;
    min-height: 30px;
}

QScrollBar::handle:vertical:hover {
    background: #8a2be2;
}

QScrollBar:horizontal {
    background: #0a0a12;
    height: 10px;
}

QScrollBar::handle:horizontal {
    background: #3d2e66;
    border-radius: 5px;
}

/* ---------- CheckBox ---------- */
QCheckBox {
    spacing: 8px;
}

QCheckBox::indicator {
    width: 18px;
    height: 18px;
    border: 1px solid #3d2e66;
    border-radius: 4px;
    background-color: #15121f;
}

QCheckBox::indicator:checked {
    background-color: #8a2be2;
    border: 1px solid #8a2be2;
}

QLabel#StatusBadgeOk {
    color: #35e0a1;
    font-weight: bold;
}

QLabel#StatusBadgeWarn {
    color: #ffb84f;
    font-weight: bold;
}

QLabel#StatusBadgeError {
    color: #ff5f7e;
    font-weight: bold;
}
"""
