"""
download_page.py
-------------------
Pagina Download: permette di aggiungere collegamenti a fonti ufficiali,
scaricare i file mostrando il progresso in tempo reale, verificarne
l'integrita' (SHA-256) e gestire i file scaricati.

Non vengono scaricati contenuti piratati: l'utente fornisce l'URL della
fonte ufficiale e nessun DRM viene aggirato o rimosso da GAMEBOX PC.
"""

import os
import subprocess
import sys

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QProgressBar, QMessageBox, QDialog,
    QFormLayout, QLineEdit, QDialogButtonBox, QAbstractItemView
)


class AddDownloadDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Aggiungi download da fonte ufficiale")
        self.setMinimumWidth(460)
        layout = QFormLayout(self)

        self.name_edit = QLineEdit()
        layout.addRow("Nome:", self.name_edit)

        self.url_edit = QLineEdit()
        self.url_edit.setPlaceholderText("https://esempio.com/installer-ufficiale.exe")
        layout.addRow("URL fonte ufficiale:", self.url_edit)

        self.sha_edit = QLineEdit()
        self.sha_edit.setPlaceholderText("Opzionale: hash SHA-256 pubblicato dal distributore")
        layout.addRow("SHA-256 atteso:", self.sha_edit)

        note = QLabel(
            "GAMEBOX PC non scarica contenuti piratati e non aggira protezioni "
            "DRM. Usa solo link di fonti ufficiali e autorizzate."
        )
        note.setWordWrap(True)
        note.setObjectName("PageSubtitle")
        layout.addRow(note)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)


class DownloadPage(QWidget):
    def __init__(self, download_manager, parent=None):
        super().__init__(parent)
        self.download_manager = download_manager
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 24, 32, 24)
        layout.setSpacing(16)

        title = QLabel("Download")
        title.setObjectName("PageTitle")
        subtitle = QLabel(
            "Aggiungi collegamenti a installer da fonti ufficiali, scaricali "
            "e verificane l'integrita' prima dell'installazione."
        )
        subtitle.setObjectName("PageSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(subtitle)

        toolbar = QHBoxLayout()
        add_btn = QPushButton("+ Aggiungi collegamento")
        add_btn.setObjectName("PrimaryButton")
        add_btn.clicked.connect(self._add_download)
        toolbar.addWidget(add_btn)
        toolbar.addStretch()
        refresh_btn = QPushButton("Aggiorna elenco")
        refresh_btn.clicked.connect(self.refresh)
        toolbar.addWidget(refresh_btn)
        layout.addLayout(toolbar)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Nome", "Stato", "Progresso", "Verificato", "Azioni"]
        )
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().setVisible(False)
        layout.addWidget(self.table, 1)

        self._progress_bars = {}
        self._active_workers = {}

    def refresh(self):
        downloads = self.download_manager.list_downloads()
        self.table.setRowCount(len(downloads))
        self._progress_bars = {}

        for row, d in enumerate(downloads):
            self.table.setItem(row, 0, QTableWidgetItem(d["name"]))
            self.table.setItem(row, 1, QTableWidgetItem(d["status"]))

            bar = QProgressBar()
            bar.setValue(d["progress"])
            self.table.setCellWidget(row, 2, bar)
            self._progress_bars[d["id"]] = bar

            verificato = "✔ Sì" if d["verified"] else ("—" if not d["expected_sha256"] else "✘ No")
            self.table.setItem(row, 3, QTableWidgetItem(verificato))

            actions_widget = QWidget()
            actions_layout = QHBoxLayout(actions_widget)
            actions_layout.setContentsMargins(4, 2, 4, 2)
            actions_layout.setSpacing(6)

            start_btn = QPushButton("Avvia")
            start_btn.clicked.connect(lambda _, d=d: self._start_download(d))
            actions_layout.addWidget(start_btn)

            folder_btn = QPushButton("Apri cartella")
            folder_btn.clicked.connect(lambda _, d=d: self._open_folder(d))
            actions_layout.addWidget(folder_btn)

            remove_btn = QPushButton("Rimuovi")
            remove_btn.setObjectName("DangerButton")
            remove_btn.clicked.connect(lambda _, d=d: self._remove_download(d))
            actions_layout.addWidget(remove_btn)

            self.table.setCellWidget(row, 4, actions_widget)

    def _add_download(self):
        dialog = AddDownloadDialog(self)
        if dialog.exec() == QDialog.Accepted:
            url = dialog.url_edit.text().strip()
            if not url:
                QMessageBox.warning(self, "Attenzione", "Devi inserire un URL valido.")
                return
            try:
                self.download_manager.add_download_record(
                    name=dialog.name_edit.text().strip() or url,
                    url=url,
                    expected_sha256=dialog.sha_edit.text().strip() or None,
                )
                self.refresh()
            except ValueError as e:
                QMessageBox.critical(self, "Errore", str(e))

    def _start_download(self, d: dict):
        try:
            worker = self.download_manager.start_download(d["id"])
        except ValueError as e:
            QMessageBox.warning(self, "Download non avviato", str(e))
            return
        self._active_workers[d["id"]] = worker

        def on_progress(download_id, percent):
            bar = self._progress_bars.get(download_id)
            if bar:
                bar.setValue(percent)

        def on_status(download_id, text):
            for row in range(self.table.rowCount()):
                item = self.table.item(row, 0)
                if item and self._row_id(row) == download_id:
                    self.table.setItem(row, 1, QTableWidgetItem(text))

        def on_finished(download_id, path, sha):
            self._active_workers.pop(download_id, None)
            self.refresh()

        def on_error(download_id, message):
            self._active_workers.pop(download_id, None)
            QMessageBox.critical(self, "Errore download", message)
            self.refresh()

        worker.progress_changed.connect(on_progress)
        worker.status_changed.connect(on_status)
        worker.finished_ok.connect(on_finished)
        worker.finished_error.connect(on_error)

    def _row_id(self, row):
        # Recupera l'id del download associato a una riga dalla lista corrente
        downloads = self.download_manager.list_downloads()
        if row < len(downloads):
            return downloads[row]["id"]
        return None

    def _open_folder(self, d: dict):
        folder = os.path.dirname(d["dest_path"]) if d["dest_path"] else None
        if not folder or not os.path.isdir(folder):
            QMessageBox.information(self, "Cartella non trovata",
                                     "Il file non e' ancora stato scaricato.")
            return
        try:
            if sys.platform == "win32":
                os.startfile(folder)
            elif sys.platform == "darwin":
                subprocess.Popen(["open", folder])
            else:
                subprocess.Popen(["xdg-open", folder])
        except OSError as e:
            QMessageBox.critical(self, "Errore", f"Impossibile aprire la cartella: {e}")

    def _remove_download(self, d: dict):
        reply = QMessageBox.question(
            self, "Conferma", "Rimuovere questo download dall'elenco?",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            try:
                self.download_manager.remove_download(d["id"], delete_file=False)
                self.refresh()
            except ValueError as e:
                QMessageBox.warning(self, "Download attivo", str(e))
