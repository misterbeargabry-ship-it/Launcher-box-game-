"""
apk_page.py
-------------
Pagina dedicata alla gestione degli APK Android: stato ADB/emulatore,
installazione, avvio e rimozione dei pacchetti importati.
"""

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTableWidget,
    QTableWidgetItem, QHeaderView, QMessageBox, QAbstractItemView
)

from apk_manager import ApkManagerError
from game_manager import GameManagerError


class ApkPage(QWidget):
    def __init__(self, game_manager, apk_manager, on_change=None, parent=None):
        super().__init__(parent)
        self.game_manager = game_manager
        self.apk_manager = apk_manager
        self.on_change = on_change
        self._build_ui()
        self.refresh()

    def _build_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(32, 24, 32, 24)
        layout.setSpacing(16)

        title = QLabel("APK Android")
        title.setObjectName("PageTitle")
        subtitle = QLabel(
            "Gestisci i pacchetti Android tramite ADB. Richiede un emulatore "
            "(es. BlueStacks, NoxPlayer) o un dispositivo con debug USB attivo."
        )
        subtitle.setObjectName("PageSubtitle")
        subtitle.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(subtitle)

        status_row = QHBoxLayout()
        self.status_label = QLabel("Verifica stato ADB...")
        self.status_label.setObjectName("StatusBadgeWarn")
        status_row.addWidget(self.status_label, 1)
        refresh_btn = QPushButton("Aggiorna stato")
        refresh_btn.clicked.connect(self.refresh)
        status_row.addWidget(refresh_btn)
        layout.addLayout(status_row)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Nome", "Pacchetto", "Stato", "Categoria", "Azioni"]
        )
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.verticalHeader().setVisible(False)
        layout.addWidget(self.table, 1)

    def refresh(self):
        adb_ok = self.apk_manager.check_adb_available()
        if not adb_ok:
            self.status_label.setText(
                "⚠ ADB non trovato. Configuralo nelle Impostazioni."
            )
            self.status_label.setObjectName("StatusBadgeError")
        else:
            device_ok = self.apk_manager.has_connected_device()
            if device_ok:
                devices = self.apk_manager.list_devices()
                self.status_label.setText(f"✔ Emulatore/dispositivo connesso: {', '.join(devices)}")
                self.status_label.setObjectName("StatusBadgeOk")
            else:
                self.status_label.setText(
                    "⚠ ADB attivo ma nessun emulatore/dispositivo collegato."
                )
                self.status_label.setObjectName("StatusBadgeWarn")
        self.status_label.setStyleSheet(self.status_label.styleSheet())  # forza refresh stile

        apks = [g for g in self.game_manager.list_games() if g["type"] == "apk"]
        self.table.setRowCount(len(apks))
        for row, game in enumerate(apks):
            self.table.setItem(row, 0, QTableWidgetItem(game["name"]))
            self.table.setItem(row, 1, QTableWidgetItem(game.get("package_name") or "—"))
            stato = "Installato" if game["installed"] else "Non installato"
            self.table.setItem(row, 2, QTableWidgetItem(stato))
            self.table.setItem(row, 3, QTableWidgetItem(game.get("category", "")))

            actions_widget = QWidget()
            actions_layout = QHBoxLayout(actions_widget)
            actions_layout.setContentsMargins(4, 2, 4, 2)
            actions_layout.setSpacing(6)

            install_btn = QPushButton("Installa")
            install_btn.clicked.connect(lambda _, g=game: self._install(g))
            actions_layout.addWidget(install_btn)

            launch_btn = QPushButton("Avvia")
            launch_btn.clicked.connect(lambda _, g=game: self._launch(g))
            actions_layout.addWidget(launch_btn)

            remove_btn = QPushButton("Rimuovi")
            remove_btn.setObjectName("DangerButton")
            remove_btn.clicked.connect(lambda _, g=game: self._remove(g))
            actions_layout.addWidget(remove_btn)

            self.table.setCellWidget(row, 4, actions_widget)

        if self.on_change:
            self.on_change()

    def _install(self, game: dict):
        try:
            self.apk_manager.install_apk(game["path"])
            package_name = game.get("package_name") or self.apk_manager.guess_package_name(game["path"])
            self.game_manager.set_installed(game["id"], True, package_name)
            QMessageBox.information(self, "Installazione completata",
                                     f"'{game['name']}' installato correttamente.")
            self.refresh()
        except ApkManagerError as e:
            QMessageBox.critical(self, "Errore installazione", str(e))

    def _launch(self, game: dict):
        package = game.get("package_name")
        if not package:
            QMessageBox.warning(
                self, "Pacchetto mancante",
                "Nome pacchetto non impostato. Modifica il gioco nella libreria "
                "e inserisci il package name (es. com.azienda.gioco), oppure "
                "installalo per rilevarlo automaticamente."
            )
            return
        try:
            self.apk_manager.launch_package(package)
            self.game_manager.register_play(game["id"])
            QMessageBox.information(self, "Avviato", f"'{game['name']}' avviato sull'emulatore.")
        except ApkManagerError as e:
            QMessageBox.critical(self, "Errore avvio", str(e))

    def _remove(self, game: dict):
        reply = QMessageBox.question(
            self, "Conferma rimozione",
            f"Rimuovere '{game['name']}' dalla libreria? "
            "(Non verra' disinstallato dall'emulatore)",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply == QMessageBox.Yes:
            self.game_manager.remove_game(game["id"])
            self.refresh()
