@echo off
setlocal
cd /d "%~dp0"
title GAMEBOX PC - Build Windows

echo.
echo ==========================================
echo        GAMEBOX PC - BUILD WINDOWS
echo ==========================================
echo.

where python >nul 2>nul
if errorlevel 1 (
  echo [ERRORE] Python 3.10+ non trovato.
  pause
  exit /b 1
)

if not exist "venv\Scripts\python.exe" python -m venv venv
if errorlevel 1 goto error
call "venv\Scripts\activate.bat"
python -m pip install --upgrade pip
if errorlevel 1 goto error
python -m pip install -r requirements.txt
if errorlevel 1 goto error

echo [BUILD] Creazione eseguibile...
python -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name GAMEBOX ^
  --icon "assets\icons\gamebox.ico" ^
  --add-data "assets;assets" ^
  --collect-all PySide6 ^
  --hidden-import pygame ^
  main.py
if errorlevel 1 goto error

echo.
echo BUILD COMPLETATA.
echo Eseguibile: dist\GAMEBOX.exe
echo I dati persistenti vengono salvati in %%LOCALAPPDATA%%\GAMEBOX_PC
echo Copertine, giochi, APK e download restano disponibili tra gli aggiornamenti.
echo.
pause
exit /b 0

:error
echo.
echo [ERRORE] Build non riuscita. Controlla i messaggi precedenti.
pause
exit /b 1
